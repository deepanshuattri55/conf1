from django.urls import path, include

from . import views

urlpatterns = [
    path('info/', views.UserDetailView.as_view(), name='account-info'),
    path('register/', views.UserRegisterView.as_view(), name='register'),
    path('login/', views.UserLoginView.as_view(), name='login'),
    path('logout/', views.UserLogoutView.as_view(), name='logout'),
    path('contact-us/', views.ContactUsView.as_view(), name='contact-us'),
    path('careers/', views.CareersView.as_view(), name='careers'),
    path('testimonials/', views.TestimonialsView.as_view(), name='testimonials'),
    path('policy/', views.PolicyView.as_view(), name='policy'),
    path('privacy/', views.PrivacyView.as_view(), name='privacy'),
    path('terms-of-service/', views.TOSView.as_view(), name='terms-of-service'),
    path('conference-create/', views.ConferenceCreateView.as_view(), name='conference-create'),
    path('license-info/', views.LicenseInfoView.as_view(), name='license-info'),
    path('license-pricing/', views.LicensePricingView.as_view(), name='license-pricing'),
    path('faq/', views.FAQView.as_view(), name='faq'),
    path('overview/', views.OverviewView.as_view(), name='overview'),
    path('registration-info/', views.RegistrationInfoView.as_view(), name='registration_info'),
    path('publishing-info/', views.PublishingInfoView.as_view(), name='publishing_info'),
    path('smart-cfp/', views.SmartCFPView.as_view(), name='smart_cfp'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('', views.IndexView.as_view(), name='index'),
]
