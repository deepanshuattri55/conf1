STATUS_CHOICES = [
    ("Accept", "Accept"),
    ("Minor", "Minor Revisions"),
    ("Major", "Major Revisions"),
    ("Reject", "Reject")
]
